package hasanalmudev.belajarjavavalidation1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarJavaValidation1Application {

	public static void main(String[] args) {
		SpringApplication.run(BelajarJavaValidation1Application.class, args);
	}

}
